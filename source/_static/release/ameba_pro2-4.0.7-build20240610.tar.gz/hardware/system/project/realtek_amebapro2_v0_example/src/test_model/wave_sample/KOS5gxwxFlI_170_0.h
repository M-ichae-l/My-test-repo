extern unsigned char KOS5gxwxFlI_170_0_wav[];
extern unsigned int KOS5gxwxFlI_170_0_wav_len;
