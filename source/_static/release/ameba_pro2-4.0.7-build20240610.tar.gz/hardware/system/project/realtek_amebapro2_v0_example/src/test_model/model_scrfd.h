#ifndef MODEL_SCRFD_H
#define MODEL_SCRFD_H

#include "module_vipnn.h"

extern nnmodel_t scrfd_fwfs;

#endif /* MODEL_SCRFD_H */