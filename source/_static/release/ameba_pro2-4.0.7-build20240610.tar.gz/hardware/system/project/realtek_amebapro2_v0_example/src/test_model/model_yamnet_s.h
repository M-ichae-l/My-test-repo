#ifndef MODEL_YAMNET_WD1_H
#define MODEL_YAMNET_WD1_H

#include "module_vipnn.h"

extern nnmodel_t yamnet_s;
#endif