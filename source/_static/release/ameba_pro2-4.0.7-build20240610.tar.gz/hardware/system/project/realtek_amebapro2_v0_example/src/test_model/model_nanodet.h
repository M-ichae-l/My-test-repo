#ifndef MODEL_NANODET_H
#define MODEL_NANODET_H

#include "module_vipnn.h"

extern nnmodel_t nanodet_plus_m;

#endif