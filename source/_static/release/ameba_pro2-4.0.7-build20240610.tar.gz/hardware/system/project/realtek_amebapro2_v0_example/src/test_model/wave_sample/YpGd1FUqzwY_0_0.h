extern unsigned char YpGd1FUqzwY_0_0_wav[];
extern unsigned int YpGd1FUqzwY_0_0_wav_len;
