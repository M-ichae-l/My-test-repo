extern unsigned char KXUnTGpPrmo_15_1_wav[];
extern unsigned int KXUnTGpPrmo_15_1_wav_len;
