#ifndef MODEL_MOBILEFACENET_H
#define MODEL_MOBILEFACENET_H

#include "module_vipnn.h"

extern nnmodel_t mbfacenet_fwfs;
extern nnmodel_t mbfacenet_nk_fwfs;

#endif /* MODEL_MOBILEFACENET_H */