#ifndef __CLASS_NAME_H__
#define __CLASS_NAME_H__

const char *coco_name_get_by_id(int id);

const char *voc_name_get_by_id(int id);

const char *audioset_name_get_by_id(int id);

#endif /* __CLASS_NAME_H__ */