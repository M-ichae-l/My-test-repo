#ifndef MODEL_RETINAFACE_H
#define MODEL_RETINAFACE_H

#include "module_vipnn.h"

extern nnmodel_t retinaface025_fwfs;

#endif /* MODEL_RETINAFACE_H */