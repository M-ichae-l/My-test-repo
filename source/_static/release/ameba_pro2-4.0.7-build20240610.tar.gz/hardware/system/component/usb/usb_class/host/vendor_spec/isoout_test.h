#ifndef ISOOUT_TEST_H
#define ISOOUT_TEST_H

/******************************************************/
/* Control define                                     */
/******************************************************/
#define USBH_ENABLE_ISOIN
#define USBH_ENABLE_ISOOUT
//--
#define USBD_ENABE_ISOIN_USB_REQ_ISO_ASAP
//#define USBD_ENABE_ISOOUT_USB_REQ_ISO_ASAP


/******************************************************/
/* Parameter define                                   */
/******************************************************/
#define USB_ISOOUT_TRANSFER_CNT		100

#endif
