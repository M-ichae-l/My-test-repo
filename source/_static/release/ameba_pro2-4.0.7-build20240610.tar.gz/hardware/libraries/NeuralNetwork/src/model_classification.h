#ifndef MODEL_CLASSIFICATION_H
#define MODEL_CLASSIFICATION_H

#include "module_vipnn.h"

void get_input_image_color(int input_image_rgb);

extern nnmodel_t img_classification;
#endif
