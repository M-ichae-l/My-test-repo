/*
 *******************************************************************************
 * Copyright(c) 2021, Realtek Semiconductor Corporation. All rights reserved.
 *******************************************************************************
 */

#ifndef __ATCMD_BT_GATTS_IMPL_H__
#define __ATCMD_BT_GATTS_IMPL_H__

#ifdef __cplusplus
extern "C" {
#endif

int atcmd_bt_gatts(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif