##################################################################################
#                                                                                                                                                                                    #
#                                                                     RTK_BT_POWER_SAVE_DEMO                                                             #
#                                                                                                                                                                                    #
##################################################################################

Date: 2022 - 06 - 13

Description
~~~~~~~~~~~
Initialize BT Power Save Demo for AmebaLite.

Setup Guide
~~~~~~~~~~~
Replace contents of bt_power_save_peripheral_demo.c with ~/sdk/component/bluetooth/example/ble_peripheral ;

[Supported List]
Supported IC :
	Ameba - Lite
