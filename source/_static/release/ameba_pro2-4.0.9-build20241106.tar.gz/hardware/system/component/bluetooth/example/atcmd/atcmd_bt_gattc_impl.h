/*
 *******************************************************************************
 * Copyright(c) 2022, Realtek Semiconductor Corporation. All rights reserved.
 *******************************************************************************
 */

#ifndef __ATCMD_BT_GATTC_IMPL_H__
#define __ATCMD_BT_GATTC_IMPL_H__

#ifdef __cplusplus
extern "C" {
#endif

int atcmd_bt_gattc(int argc, char* argv[]);

#ifdef __cplusplus
}
#endif

#endif
